class Workout {
  final String name;
  final bool isDone;

  Workout({required this.name, this.isDone = false});
}