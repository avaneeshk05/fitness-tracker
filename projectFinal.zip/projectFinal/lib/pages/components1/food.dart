class Food {
  final String name;
  final int calories;
  final String nutritionBenefits;

  Food({required this.name, required this.calories, required this.nutritionBenefits});

}